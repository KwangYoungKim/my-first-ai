// app.js - main script handling UI navigation and feature logic

// Helper to select elements
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

// Tab navigation
function initTabs() {
  $$('.tab').forEach(btn => {
    btn.addEventListener('click', () => {
      const target = btn.dataset.tab;
      $$('.panel').forEach(p => p.classList.toggle('active', p.id === target));
    });
  });
}

/* ==================== Calculator ==================== */
function evaluateExpression(expr) {
  // Convert degree trig functions to radians
  const degToRad = (deg) => deg * Math.PI / 180;
  // Replace functions with Math equivalents
  let safeExpr = expr
    .replace(/sin\s*\(([^)]+)\)/gi, (_, p) => `Math.sin(degToRad(${p.trim()}))`)
    .replace(/cos\s*\(([^)]+)\)/gi, (_, p) => `Math.cos(degToRad(${p.trim()}))`)
    .replace(/tan\s*\(([^)]+)\)/gi, (_, p) => `Math.tan(degToRad(${p.trim()}))`)
    .replace(/log\s*\(([^)]+)\)/gi, (_, p) => `Math.log10(${p.trim()})`)
    .replace(/sqrt\s*\(([^)]+)\)/gi, (_, p) => `Math.sqrt(${p.trim()})`)
    .replace(/\^/g, '**'); // exponentiation
  try {
    // eslint-disable-next-line no-eval
    const result = eval(safeExpr);
    return isNaN(result) || !isFinite(result) ? 'Error' : result;
  } catch (e) {
    return 'Error';
  }
}

function initCalculator() {
  const exprInput = $('#calcExpr');
  const resultSpan = $('#calcResult');
  const equalsBtn = $('#calcEquals');

  // Handle key presses
  $$('.calc-key').forEach(btn => {
    btn.addEventListener('click', () => {
      const key = btn.textContent.trim();
      if (key === 'C') {
        exprInput.value = '';
        resultSpan.textContent = '';
      } else if (key === '=') {
        const res = evaluateExpression(exprInput.value);
        resultSpan.textContent = res;
      } else {
        exprInput.value += key;
      }
    });
  });

  // Also allow pressing Enter key for evaluation
  equalsBtn.addEventListener('click', () => {
    const res = evaluateExpression(exprInput.value);
    resultSpan.textContent = res;
  });
}

/* ==================== To‑Do List ==================== */
function loadTodos() {
  const data = JSON.parse(localStorage.getItem('todos') || '[]');
  const list = $('#todoList');
  list.innerHTML = '';
  data.forEach((t, i) => {
    const li = document.createElement('li');
    const span = document.createElement('span');
    span.textContent = t.text;
    const del = document.createElement('button');
    del.textContent = '✕';
    del.addEventListener('click', () => {
      data.splice(i, 1);
      localStorage.setItem('todos', JSON.stringify(data));
      loadTodos();
    });
    li.appendChild(span);
    li.appendChild(del);
    list.appendChild(li);
  });
}

function addTodo() {
  const txt = $('#newTodo').value.trim();
  if (!txt) return;
  const data = JSON.parse(localStorage.getItem('todos') || '[]');
  data.push({ text: txt });
  localStorage.setItem('todos', JSON.stringify(data));
  $('#newTodo').value = '';
  loadTodos();
}

function initTodo() {
  $('#addTodoBtn').addEventListener('click', addTodo);
  loadTodos();
}

/* ==================== Calendar & Diary ==================== */
function initCalendarControls() {
  const yearSelect = $('#yearSelect');
  const monthSelect = $('#monthSelect');
  const currentYear = new Date().getFullYear();
  for (let y = currentYear - 10; y <= currentYear + 10; y++) {
    const opt = document.createElement('option');
    opt.value = y;
    opt.textContent = y;
    if (y === currentYear) opt.selected = true;
    yearSelect.appendChild(opt);
  }
  for (let m = 1; m <= 12; m++) {
    const opt = document.createElement('option');
    opt.value = m;
    opt.textContent = m;
    if (m === new Date().getMonth() + 1) opt.selected = true;
    monthSelect.appendChild(opt);
  }
  yearSelect.addEventListener('change', () => renderCalendar());
  monthSelect.addEventListener('change', () => renderCalendar());
}

// Render the calendar grid with weekday headers
function renderCalendar() {
  const grid = $('#calendarGrid');
  grid.innerHTML = '';

  // Weekday header
  const weekdays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  weekdays.forEach(w => {
    const hdr = document.createElement('div');
    hdr.className = 'weekday';
    hdr.textContent = w;
    grid.appendChild(hdr);
  });

  const year = parseInt($('#yearSelect').value);
  const month = parseInt($('#monthSelect').value) - 1; // zero‑based
  const first = new Date(year, month, 1);
  const startDay = first.getDay(); // 0 Sun
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  // Fill blanks before first day
  for (let i = 0; i < startDay; i++) {
    const blank = document.createElement('div');
    blank.className = 'day blank';
    grid.appendChild(blank);
  }

  // Populate days
  for (let d = 1; d <= daysInMonth; d++) {
    const day = document.createElement('div');
    day.className = 'day';
    day.textContent = d;
    const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
    day.dataset.date = dateStr;
    day.addEventListener('click', () => openEventInput(dateStr));
    grid.appendChild(day);
  }
}

function openEventInput(date) {
  $('#eventDateHeader').textContent = `Events for ${date}`;
  $('#eventInput').style.display = 'block';
  $('#eventList').innerHTML = '';
  const events = JSON.parse(localStorage.getItem('events') || '{}');
  const list = $('#eventList');
  (events[date] || []).forEach((e, i) => {
    const div = document.createElement('div');
    div.textContent = e;
    const del = document.createElement('button');
    del.textContent = '✕';
    del.addEventListener('click', () => {
      const arr = events[date];
      arr.splice(i, 1);
      localStorage.setItem('events', JSON.stringify(events));
      openEventInput(date);
    });
    div.appendChild(del);
    list.appendChild(div);
  });
  $('#saveEventBtn').onclick = () => {
    const txt = $('#eventText').value.trim();
    if (!txt) return;
    const ev = JSON.parse(localStorage.getItem('events') || '{}');
    if (!ev[date]) ev[date] = [];
    ev[date].push(txt);
    localStorage.setItem('events', JSON.stringify(ev));
    $('#eventText').value = '';
    openEventInput(date);
  };
  $('#cancelEventBtn').onclick = () => {
    $('#eventInput').style.display = 'none';
    $('#eventText').value = '';
  };
}

function initCalendarDiary() {
  initCalendarControls();
  renderCalendar();
}

function openDiary(date) {
  const view = $('#diaryView');
  view.innerHTML = `<h3>${date}</h3><textarea id="diaryText"></textarea><br/><button id="saveDiaryBtn">Save</button>`;
  const diaryData = JSON.parse(localStorage.getItem('diary') || '{}');
  const textarea = $('#diaryText');
  textarea.value = diaryData[date] || '';
  $('#saveDiaryBtn').addEventListener('click', () => {
    diaryData[date] = textarea.value;
    localStorage.setItem('diary', JSON.stringify(diaryData));
    alert('Saved');
  });
}

// Duplicate initCalendarDiary removed – original implementation calls initCalendarControls + renderCalendar.

/* ==================== Translator ==================== */
let dict = {};
async function loadDictionary() {
  try {
    const resp = await fetch('dictionary.json');
    const data = await resp.json();
    dict = data;
  } catch (e) {
    console.error('Dictionary load error', e);
  }
}

function searchTerm() {
  const term = $('#searchTerm').value.trim().toLowerCase();
  const results = [];
  for (const [ko, en] of Object.entries(dict)) {
    if (ko.includes(term) || en.toLowerCase().includes(term)) {
      results.push(`${ko} ⟷ ${en}`);
    }
  }
  const ul = $('#searchResults');
  ul.innerHTML = '';
  results.forEach(r => {
    const li = document.createElement('li');
    li.textContent = r;
    ul.appendChild(li);
  });
}

function addPair() {
  const ko = $('#koWord').value.trim();
  const en = $('#enWord').value.trim();
  if (!ko || !en) return;
  dict[ko] = en;
  // persist custom pairs locally
  const custom = JSON.parse(localStorage.getItem('customDict') || '{}');
  custom[ko] = en;
  localStorage.setItem('customDict', JSON.stringify(custom));
  $('#koWord').value = '';
  $('#enWord').value = '';
  alert('Added');
}

function initTranslator() {
  loadDictionary().then(() => {
    // merge custom dict if any
    const custom = JSON.parse(localStorage.getItem('customDict') || '{}');
    Object.assign(dict, custom);
  });
  $('#searchBtn').addEventListener('click', searchTerm);
  $('#addPairBtn').addEventListener('click', addPair);
}

/* ==================== Init ==================== */
window.addEventListener('DOMContentLoaded', () => {
  initTabs();
  initCalculator();
  initTodo();
  initCalendarDiary();
  initTranslator();
});
