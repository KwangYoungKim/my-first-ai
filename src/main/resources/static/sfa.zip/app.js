// ====================================================
// 보험설계사 스마트 워크스페이스 - Core Logic (app.js)
// ====================================================

// ----------------------------------------------------
// 1. Data Store / State (로컬 스토리지 연동)
// ----------------------------------------------------

const defaultClients = [
    { id: "c-1", name: "홍길동", phone: "010-5555-1234", type: "vip", policy: "종합 건강 보험, 종신 보험", notes: "자산가형 고객. 연금 저축 보험 추가 제안 요청 상태." },
    { id: "c-2", name: "이영희", phone: "010-8888-5678", type: "active", policy: "실손 의료비 보험, 암 보험", notes: "내일 생일(6/9). 친근한 커뮤니케이션 선호. 사은품 증정 대상." },
    { id: "c-3", name: "김민수", phone: "010-9999-4321", type: "prospect", policy: "운전자 보험 설계중", notes: "지인 소개 고객. 가성비 높은 담보 구성 위주로 제안 요청." },
    { id: "c-4", name: "박수진", phone: "010-2222-7777", type: "active", policy: "종합 간병인 보험", notes: "가족력(뇌혈관 질환) 걱정이 많으므로 추가 보장 검토 권유 예정." }
];

const defaultEvents = [
    { id: "e-1", date: "2026-06-08", time: "10:00", title: "홍길동 고객님 종신보험 청약서 서명", type: "sign", clientId: "c-1" },
    { id: "e-2", date: "2026-06-08", time: "14:00", title: "김민수 고객님 보장분석 제안 미팅", type: "meeting", clientId: "c-3" },
    { id: "e-3", date: "2026-06-08", time: "16:30", title: "박수진 고객님 기존 계약 리뷰 콜", type: "call", clientId: "c-4" },
    { id: "e-4", date: "2026-06-09", time: "11:00", title: "이영희 고객님 생일 기념품 발송", type: "etc", clientId: "c-2" },
    { id: "e-5", date: "2026-06-12", time: "13:30", title: "신규 화재보험 가망고객 상담 개척", type: "meeting", clientId: "" }
];

const defaultTasks = [
    { id: "t-1", title: "홍길동 고객님 청약서 보완 서류 인쇄", category: "contract", priority: "high", dueDate: "2026-06-08", completed: true },
    { id: "t-2", title: "김민수 고객님 맞춤형 보장 분석서 출력", category: "consult", priority: "high", dueDate: "2026-06-08", completed: false },
    { id: "t-3", title: "박수진 고객님 실비보험 청구 보완 심사 대응", category: "review", priority: "medium", dueDate: "2026-06-09", completed: false },
    { id: "t-4", title: "이영희 고객님 생일 안부 기프티콘 예약 발송", category: "care", priority: "low", dueDate: "2026-06-09", completed: false },
    { id: "t-5", title: "월말 마감 실적 현황 검토 및 수석 승급 요건 체크", category: "contract", priority: "high", dueDate: "2026-06-30", completed: false }
];

const defaultDiaries = {
    "2026-06-08": "오늘 오전 홍길동 VIP 고객님을 만나 계약 청약을 성공적으로 체결했다. 보장 분석에 대해 만족도가 매우 크셨음. 오후에는 가망 고객인 김민수님과의 면담이 예정되어 있어 제안 자료 준비를 한번 더 체크함."
};

// Initialize State
let clients = JSON.parse(localStorage.getItem("insu_clients")) || defaultClients;
let events = JSON.parse(localStorage.getItem("insu_events")) || defaultEvents;
let tasks = JSON.parse(localStorage.getItem("insu_tasks")) || defaultTasks;
let diaries = JSON.parse(localStorage.getItem("insu_diaries")) || defaultDiaries;

// Save helper function
function saveToLocalStorage() {
    localStorage.setItem("insu_clients", JSON.stringify(clients));
    localStorage.setItem("insu_events", JSON.stringify(events));
    localStorage.setItem("insu_tasks", JSON.stringify(tasks));
    localStorage.setItem("insu_diaries", JSON.stringify(diaries));
}

// ----------------------------------------------------
// 2. DOM Elements & Navigation Setup (교정 완료)
// ----------------------------------------------------

document.addEventListener("DOMContentLoaded", () => {
    // Lucide Icons initialization
    lucide.createIcons();

    // Tab Navigation
    const navItems = document.querySelectorAll(".nav-item");
    const tabPanes = document.querySelectorAll(".tab-pane");
    const pageTitle = document.getElementById("page-title");

    navItems.forEach(item => {
        item.addEventListener("click", (e) => {
            e.preventDefault();
            const tabId = item.getAttribute("data-tab");

            navItems.forEach(nav => nav.classList.remove("active"));
            item.classList.add("active");

            tabPanes.forEach(pane => {
                pane.classList.remove("active");
                if (pane.id === `tab-${tabId}`) {
                    pane.classList.add("active");
                }
            });

            const tabNames = {
                dashboard: "종합 대시보드",
                calendar: "캘린더 & 다이어리",
                tasks: "영업 할 일 목록",
                clients: "Marketing 고객 관리"
            };
            pageTitle.textContent = tabNames[tabId];

            if (tabId === "dashboard") {
                updateDashboard();
            } else if (tabId === "calendar") {
                renderCalendar();
            } else if (tabId === "tasks") {
                renderTasks();
            } else if (tabId === "clients") {
                renderClients();
            }
        });
    });

    // Date displays
    updateCurrentDateDisplay();

    // Modals handling
    initModals();

    // Forms handling
    initForms();

    // Diary auto-save feature
    initDiaryAutoSave();

    // Initial Dashboard Populate
    updateDashboard();

    // Populate Client Select Options for Event Form
    populateClientSelects();

    // Navigate to Calendar from Dashboard
    document.getElementById("btn-goto-calendar").addEventListener("click", () => {
        const calNavItem = document.querySelector('[data-tab="calendar"]');
        if (calNavItem) calNavItem.click();
    });

    // Handle Month Navigation buttons
    const prevBtn = document.getElementById("prev-month-btn");
    const nextBtn = document.getElementById("next-month-btn");
    const todayBtn = document.getElementById("today-btn");

    if (prevBtn && nextBtn && todayBtn) {
        prevBtn.addEventListener("click", () => {
            currentMonth--;
            if (currentMonth < 0) {
                currentMonth = 11;
                currentYear--;
            }
            renderCalendar();
        });

        nextBtn.addEventListener("click", () => {
            currentMonth++;
            if (currentMonth > 11) {
                currentMonth = 0;
                currentYear++;
            }
            renderCalendar();
        });

        todayBtn.addEventListener("click", () => {
            const today = new Date();
            currentYear = today.getFullYear();
            currentMonth = today.getMonth();
            selectedDateStr = getTodayDateStr();
            renderCalendar();
        });
    }

    // Search input event for client list
    const clientSearchInput = document.getElementById("client-search-input");
    if (clientSearchInput) {
        clientSearchInput.addEventListener("input", renderClients);
    }

    // Search input keyup event for tasks
    const taskSearchInput = document.getElementById("task-search-input");
    if (taskSearchInput) {
        taskSearchInput.addEventListener("input", renderTasks);
    }
}); // <--- DOMContentLoaded 이벤트 리스너를 여기서 안전하게 닫아 외부 노출 성공!

// Update today's date in top header
function updateCurrentDateDisplay() {
    const today = new Date();
    const options = { year: 'numeric', month: 'long', day: 'numeric', weekday: 'long' };
    const dateStr = today.toLocaleDateString('ko-KR', options);
    document.getElementById("current-date-display").textContent = dateStr;
}

// ----------------------------------------------------
// 3. Modal Functionality
// ----------------------------------------------------

// 알림 데이터를 전역으로 저장 (notification-bell 팝업에서 재사용)
let currentAlerts = [];

function initModals() {
    const modalButtons = [
        { btnId: "btn-open-event-modal", modalId: "event-modal" },
        { btnId: "btn-open-task-modal", modalId: "task-modal" },
        { btnId: "btn-open-client-modal", modalId: "client-modal" }
    ];

    modalButtons.forEach(config => {
        const btn = document.getElementById(config.btnId);
        const modal = document.getElementById(config.modalId);
        if (btn && modal) {
            btn.addEventListener("click", () => {
                modal.classList.add("active");
                if (config.modalId === "event-modal") {
                    populateClientSelects();
                }
            });
        }
    });

    // notification-bell 클릭 → 알림 목록 팝업 열기
    const notiBell = document.querySelector(".notification-bell");
    if (notiBell) {
        notiBell.addEventListener("click", () => {
            openAlertListModal();
        });
    }

    const closeBtns = document.querySelectorAll(".btn-close-modal");
    closeBtns.forEach(btn => {
        btn.addEventListener("click", (e) => {
            e.preventDefault();
            const openModal = btn.closest(".modal-overlay");
            if (openModal) openModal.classList.remove("active");
        });
    });

    const overlays = document.querySelectorAll(".modal-overlay");
    overlays.forEach(overlay => {
        overlay.addEventListener("click", (e) => {
            if (e.target === overlay) {
                overlay.classList.remove("active");
            }
        });
    });
}

// notification-bell 클릭 시 알림 목록을 모달로 렌더링
function openAlertListModal() {
    const modal = document.getElementById("alert-list-modal");
    const listEl = document.getElementById("alert-modal-list");
    if (!modal || !listEl) return;

    listEl.innerHTML = "";

    if (currentAlerts.length === 0) {
        listEl.innerHTML = `<li style="padding:1.2rem; text-align:center; color:var(--text-muted); font-size:0.88rem;">새로운 알림이 없습니다.</li>`;
    } else {
        currentAlerts.forEach(alert => {
            const li = document.createElement("li");
            li.className = `alert-item ${alert.type}`;
            li.style.cursor = "default";
            li.innerHTML = `
                <i data-lucide="${alert.icon}" class="alert-icon"></i>
                <div class="alert-text">${alert.text}</div>
            `;
            listEl.appendChild(li);
        });
    }

    modal.classList.add("active");
    lucide.createIcons();
}

function populateClientSelects() {
    const select = document.getElementById("event-client-select");
    if (!select) return;

    select.innerHTML = '<option value="">고객을 선택해 주세요 (무관할 시 비워둠)</option>';
    clients.forEach(c => {
        const option = document.createElement("option");
        option.value = c.id;
        option.textContent = `${c.name} (${c.phone})`;
        select.appendChild(option);
    });
}

// ----------------------------------------------------
// 4. Forms Submission Handlers
// ----------------------------------------------------

function initForms() {
    const eventForm = document.getElementById("event-form");
    if (eventForm) {
        eventForm.addEventListener("submit", (e) => {
            e.preventDefault();
            const title = document.getElementById("event-title").value;
            const time = document.getElementById("event-time").value;
            const type = document.getElementById("event-type").value;
            const clientId = document.getElementById("event-client-select").value;

            const newEvent = {
                id: `e-${Date.now()}`,
                date: selectedDateStr,
                time,
                title,
                type,
                clientId
            };

            events.push(newEvent);
            saveToLocalStorage();
            eventForm.reset();
            document.getElementById("event-modal").classList.remove("active");

            renderCalendar();
            renderSelectedDayDetails(selectedDateStr);
            updateDashboard();
        });
    }

    const taskForm = document.getElementById("task-form");
    if (taskForm) {
        taskForm.addEventListener("submit", (e) => {
            e.preventDefault();
            const title = document.getElementById("task-title").value;
            const category = document.getElementById("task-category").value;
            const priority = document.getElementById("task-priority").value;
            const dueDate = document.getElementById("task-date").value;

            const newTask = {
                id: `t-${Date.now()}`,
                title,
                category,
                priority,
                dueDate,
                completed: false
            };

            tasks.push(newTask);
            saveToLocalStorage();
            taskForm.reset();
            document.getElementById("task-modal").classList.remove("active");

            renderTasks();
            updateDashboard();
        });
    }

    const clientForm = document.getElementById("client-form");
    if (clientForm) {
        clientForm.addEventListener("submit", (e) => {
            e.preventDefault();
            const name = document.getElementById("client-name").value;
            const phone = document.getElementById("client-phone").value;
            const type = document.getElementById("client-type").value;
            const policy = document.getElementById("client-policy").value;
            const notes = document.getElementById("client-notes").value;

            const newClient = {
                id: `c-${Date.now()}`,
                name,
                phone,
                type,
                policy: policy || "기록 없음",
                notes: notes || ""
            };

            clients.push(newClient);
            saveToLocalStorage();
            clientForm.reset();
            document.getElementById("client-modal").classList.remove("active");

            renderClients();
            updateDashboard();
        });
    }
}

// ----------------------------------------------------
// 5. Dashboard Tab Engine
// ----------------------------------------------------

function updateDashboard() {
    const todayStr = getTodayDateStr();

    const todaysEvents = events.filter(e => e.date === todayStr);
    document.getElementById("stat-today-meetings").textContent = `${todaysEvents.length} 건`;

    const pendingReviews = tasks.filter(t => t.category === "review" && !t.completed);
    document.getElementById("stat-pending-reviews").textContent = `${pendingReviews.length} 건`;

    const totalContractTasks = tasks.filter(t => t.category === "contract").length;
    const completedContractTasks = tasks.filter(t => t.category === "contract" && t.completed).length;

    let baseGoalPercent = 65;
    if (totalContractTasks > 0) {
        baseGoalPercent = Math.min(100, Math.round(65 + (completedContractTasks / totalContractTasks) * 35));
    }

    document.getElementById("goal-progress-fill").style.width = `${baseGoalPercent}%`;
    document.getElementById("goal-progress-text").textContent = `${baseGoalPercent}%`;
    document.getElementById("goal-radial-value").textContent = `${baseGoalPercent}%`;

    const radialGauge = document.querySelector(".goal-circular-progress");
    if (radialGauge) {
        const degrees = Math.round(baseGoalPercent * 3.6);
        radialGauge.style.background = `conic-gradient(var(--accent-blue) ${degrees}deg, rgba(255, 255, 255, 0.05) 0deg)`;
    }

    const currentAmount = Math.round(1000 * (baseGoalPercent / 100));
    document.getElementById("goal-current-amount").textContent = `${currentAmount} 만원`;
    document.getElementById("stat-monthly-contracts").textContent = `${Math.round(baseGoalPercent / 10)} 건`;

    const timelineContainer = document.getElementById("dash-timeline");
    timelineContainer.innerHTML = "";

    if (todaysEvents.length === 0) {
        timelineContainer.innerHTML = '<div class="timeline-empty">오늘 등록된 미팅 일정이 없습니다.</div>';
    } else {
        const sortedEvents = [...todaysEvents].sort((a, b) => a.time.localeCompare(b.time));
        sortedEvents.forEach(e => {
            const node = document.createElement("div");
            node.className = `timeline-node type-${e.type}`;

            let clientMarkup = "";
            if (e.clientId) {
                const client = clients.find(c => c.id === e.clientId);
                if (client) {
                    clientMarkup = `<span class="timeline-client"><i data-lucide="user" style="width:11px;height:11px;display:inline-block;vertical-align:-1px;margin-right:2px;"></i> ${client.name} (${client.phone})</span>`;
                }
            }

            node.innerHTML = `
                <div class="timeline-time">${e.time}</div>
                <div class="timeline-content">
                    <div class="timeline-title">${e.title}</div>
                    ${clientMarkup}
                </div>
            `;
            timelineContainer.appendChild(node);
        });
        lucide.createIcons();
    }

    updateDashboardAlerts();
}

function updateDashboardAlerts() {
    const alertList = document.getElementById("dash-alerts");
    if (!alertList) return;
    alertList.innerHTML = "";

    // 전역 배열에 저장 → notification-bell 팝업에서 재사용
    currentAlerts = [];

    const birthdayClients = clients.filter(c => c.notes.includes("생일: 6월 9일") || c.notes.includes("내일 생일") || c.id === "c-2");
    birthdayClients.forEach(c => {
        currentAlerts.push({
            type: "info",
            icon: "gift",
            text: `<strong>${c.name} 고객님</strong> 내일 생일 (안부 문자 및 기념품 추천)`
        });
    });

    const highTasks = tasks.filter(t => t.priority === "high" && !t.completed);
    highTasks.forEach(t => {
        currentAlerts.push({
            type: "warn",
            icon: "alert-circle",
            text: `<strong>[긴급 할일]</strong> ${t.title} (기한: ${t.dueDate})`
        });
    });

    currentAlerts.push({
        type: "warn",
        icon: "refresh-cw",
        text: `<strong>홍길동 고객님</strong> 보유 실손의료비보험 갱신 만기 D-7`
    });

    // 대시보드 카드에는 최대 3건만 표시
    currentAlerts.slice(0, 3).forEach(alert => {
        const li = document.createElement("li");
        li.className = `alert-item ${alert.type}`;
        li.innerHTML = `
            <i data-lucide="${alert.icon}" class="alert-icon"></i>
            <div class="alert-text">${alert.text}</div>
        `;
        alertList.appendChild(li);
    });

    document.getElementById("alert-count").textContent = currentAlerts.length;
    lucide.createIcons();
}

function getTodayDateStr() {
    const today = new Date();
    const y = today.getFullYear();
    const m = String(today.getMonth() + 1).padStart(2, "0");
    const d = String(today.getDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
}

// ----------------------------------------------------
// 6. Calendar & Diary Engine (완벽 교정 버전)
// ----------------------------------------------------
const todayDateObj = new Date();

let currentYear = todayDateObj.getFullYear();
let currentMonth = todayDateObj.getMonth();
let selectedDateStr = `${currentYear}-${String(currentMonth + 1).padStart(2, "0")}-${String(todayDateObj.getDate()).padStart(2, "0")}`;

function renderCalendar() {
    const grid = document.getElementById("calendar-days-grid");
    if (!grid) return;
    grid.innerHTML = "";

    const monthYearTitle = document.getElementById("calendar-month-year");
    const monthsName = ["1월", "2월", "3월", "4월", "5월", "6월", "7월", "8월", "9월", "10월", "11월", "12월"];
    monthYearTitle.textContent = `${currentYear}년 ${monthsName[currentMonth]}`;

    const firstDayIndex = new Date(currentYear, currentMonth, 1).getDay();
    const lastDay = new Date(currentYear, currentMonth + 1, 0).getDate();
    const prevLastDay = new Date(currentYear, currentMonth, 0).getDate();
    const todayStr = getTodayDateStr();

    // 1. 이전 달 빈칸 채우기
    for (let x = firstDayIndex; x > 0; x--) {
        const dayCell = document.createElement("div");
        dayCell.className = "calendar-day-cell outside";
        dayCell.innerHTML = `<span class="day-number">${prevLastDay - x + 1}</span>`;
        grid.appendChild(dayCell);
    }

    // 2. 이번 달 날짜 채우기
    for (let i = 1; i <= lastDay; i++) {
        const dayCell = document.createElement("div");
        dayCell.className = "calendar-day-cell";

        const dayOfWeek = new Date(currentYear, currentMonth, i).getDay();
        if (dayOfWeek === 0) dayCell.classList.add("sunday");
        if (dayOfWeek === 6) dayCell.classList.add("saturday");

        const mStr = String(currentMonth + 1).padStart(2, "0");
        const dStr = String(i).padStart(2, "0");
        const dateStr = `${currentYear}-${mStr}-${dStr}`;

        if (dateStr === todayStr) dayCell.classList.add("today");
        if (dateStr === selectedDateStr) dayCell.classList.add("selected");

        dayCell.innerHTML = `
            <span class="day-number">${i}</span>
            <div class="day-indicators"></div>
        `;

        const dayIndicators = dayCell.querySelector(".day-indicators");
        const dayEvents = events.filter(e => e.date === dateStr);
        dayEvents.slice(0, 3).forEach(e => {
            const dot = document.createElement("span");
            dot.className = `indicator-dot ${e.type}`;
            dayIndicators.appendChild(dot);
        });

        dayCell.addEventListener("click", () => {
            document.querySelectorAll(".calendar-day-cell").forEach(cell => {
                cell.classList.remove("selected");
            });
            dayCell.classList.add("selected");
            selectedDateStr = dateStr;
            renderSelectedDayDetails(dateStr);
        });

        grid.appendChild(dayCell);
    }

    // 3. 다음 달 빈칸 채우기
    const totalCells = grid.children.length;
    const remainingCells = (7 - (totalCells % 7)) % 7;
    for (let i = 1; i <= remainingCells; i++) {
        const dayCell = document.createElement("div");
        dayCell.className = "calendar-day-cell outside";
        dayCell.innerHTML = `<span class="day-number">${i}</span>`;
        grid.appendChild(dayCell);
    }

    renderSelectedDayDetails(selectedDateStr);
}

function renderSelectedDayDetails(dateStr) {
    const [year, month, day] = dateStr.split("-").map(Number);
    const dateObj = new Date(year, month - 1, day);
    const options = { month: 'long', day: 'numeric', weekday: 'short' };
    const titleText = dateObj.toLocaleDateString('ko-KR', options);

    document.getElementById("selected-date-title").textContent = `${titleText} 일정 & 상담 일지`;

    const dayEventsList = document.getElementById("day-events-list");
    if (!dayEventsList) return;
    dayEventsList.innerHTML = "";

    const dayEvents = events.filter(e => e.date === dateStr);

    if (dayEvents.length === 0) {
        dayEventsList.innerHTML = '<div class="events-empty">등록된 일정이 없습니다.</div>';
    } else {
        const sorted = [...dayEvents].sort((a, b) => a.time.localeCompare(b.time));
        sorted.forEach(e => {
            const item = document.createElement("div");
            item.className = "side-event-item";
            item.innerHTML = `
                <div class="event-info-wrapper">
                    <span class="event-dot-marker ${e.type}"></span>
                    <div>
                        <div class="event-title-text">${e.title}</div>
                        <span class="event-time-badge">${e.time}</span>
                    </div>
                </div>
                <button class="btn-delete-event" data-id="${e.id}">
                    <i data-lucide="trash-2"></i>
                </button>
            `;

            item.querySelector(".btn-delete-event").addEventListener("click", (evt) => {
                evt.stopPropagation();
                events = events.filter(ev => ev.id !== e.id);
                saveToLocalStorage();
                renderCalendar();
                updateDashboard();
            });

            dayEventsList.appendChild(item);
        });
        lucide.createIcons();
    }

    const diaryTextarea = document.getElementById("day-diary-textarea");
    if (diaryTextarea) diaryTextarea.value = diaries[dateStr] || "";
}

function initDiaryAutoSave() {
    const diaryTextarea = document.getElementById("day-diary-textarea");
    const saveStatus = document.getElementById("diary-save-status");
    if (!diaryTextarea || !saveStatus) return;
    let timer;

    diaryTextarea.addEventListener("input", () => {
        saveStatus.textContent = "저장 중...";
        saveStatus.style.color = "var(--accent-orange)";

        clearTimeout(timer);
        timer = setTimeout(() => {
            diaries[selectedDateStr] = diaryTextarea.value;
            saveToLocalStorage();
            saveStatus.textContent = "자동 저장됨";
            saveStatus.style.color = "var(--accent-green)";
        }, 800);
    });
}

// ----------------------------------------------------
// 7. To Do List Engine
// ----------------------------------------------------
let activeTaskFilter = "all";

function renderTasks() {
    const container = document.getElementById("tasks-list-container");
    if (!container) return;
    container.innerHTML = "";

    const searchInput = document.getElementById("task-search-input").value.toLowerCase();

    let filteredTasks = tasks.filter(t => {
        const matchesCategory = activeTaskFilter === "all" || t.category === activeTaskFilter;
        const matchesSearch = t.title.toLowerCase().includes(searchInput);
        return matchesCategory && matchesSearch;
    });

    const totalTodoProgress = tasks.filter(t => !t.completed).length;
    const totalTodoHigh = tasks.filter(t => t.priority === "high" && !t.completed).length;
    const totalTodoCompleted = tasks.filter(t => t.completed).length;

    document.getElementById("count-todo-progress").textContent = totalTodoProgress;
    document.getElementById("count-todo-high").textContent = totalTodoHigh;
    document.getElementById("count-todo-completed").textContent = totalTodoCompleted;

    if (filteredTasks.length === 0) {
        container.innerHTML = `
            <div class="glass-panel" style="grid-column: 1/-1; padding: 3rem; text-align: center; color: var(--text-muted);">
                조건에 맞는 할 일 목록이 없습니다. 신규 일정을 등록하세요!
            </div>
        `;
        return;
    }

    const priorityWeight = { high: 3, medium: 2, low: 1 };
    filteredTasks.sort((a, b) => {
        if (a.completed !== b.completed) return a.completed ? 1 : -1;
        if (priorityWeight[b.priority] !== priorityWeight[a.priority]) return priorityWeight[b.priority] - priorityWeight[a.priority];
        return a.dueDate.localeCompare(b.dueDate);
    });

    filteredTasks.forEach(t => {
        const card = document.createElement("div");
        card.className = `task-card glass-panel cat-${t.category} ${t.completed ? 'completed' : ''}`;

        const categoryNames = { consult: "상담", contract: "계약/청약", review: "심사대응", care: "고객케어" };
        const todayStr = getTodayDateStr();
        const isUrgent = t.dueDate <= todayStr && !t.completed;

        card.innerHTML = `
            <div class="task-card-header">
                <label class="task-checkbox-label">
                    <span class="task-checkbox">
                        <i data-lucide="check"></i>
                    </span>
                    <span>${t.title}</span>
                </label>
                <button class="btn-task-delete" data-id="${t.id}">
                    <i data-lucide="trash-2"></i>
                </button>
            </div>
            <div class="task-card-footer">
                <span class="task-badge-category">${categoryNames[t.category]}</span>
                <div class="task-due-date ${isUrgent ? 'urgent' : ''}">
                    <i data-lucide="calendar"></i>
                    <span>${t.dueDate} 마감</span>
                </div>
                <span class="task-priority-indicator priority-${t.priority}">${t.priority === 'high' ? '긴급' : t.priority === 'medium' ? '보통' : '낮음'}</span>
            </div>
        `;

        card.querySelector(".task-checkbox").addEventListener("click", (evt) => {
            evt.preventDefault();
            t.completed = !t.completed;
            saveToLocalStorage();
            renderTasks();
            updateDashboard();
        });

        card.querySelector(".btn-task-delete").addEventListener("click", (evt) => {
            evt.stopPropagation();
            tasks = tasks.filter(tk => tk.id !== t.id);
            saveToLocalStorage();
            renderTasks();
            updateDashboard();
        });

        container.appendChild(card);
    });

    lucide.createIcons();
}

const filterButtons = document.querySelectorAll(".btn-filter");
filterButtons.forEach(btn => {
    btn.addEventListener("click", () => {
        filterButtons.forEach(b => b.classList.remove("active"));
        btn.classList.add("active");
        activeTaskFilter = btn.getAttribute("data-filter");
        renderTasks();
    });
});

// ----------------------------------------------------
// 8. Client Management Engine
// ----------------------------------------------------

function renderClients() {
    const container = document.getElementById("clients-grid-container");
    if (!container) return;
    container.innerHTML = "";

    const searchInput = document.getElementById("client-search-input").value.toLowerCase();

    const filteredClients = clients.filter(c => {
        return c.name.toLowerCase().includes(searchInput) || c.phone.includes(searchInput);
    });

    if (filteredClients.length === 0) {
        container.innerHTML = `
            <div class="glass-panel" style="grid-column: 1/-1; padding: 3rem; text-align: center; color: var(--text-muted);">
                검색 조건에 일치하는 고객이 없습니다. 신규 고객을 등록해보세요!
            </div>
        `;
        return;
    }

    filteredClients.forEach(c => {
        const card = document.createElement("div");
        card.className = "client-card glass-panel";

        const firstLetter = c.name.substring(0, 1);
        const clientTypeNames = { prospect: "가망 고객", active: "계약 고객", vip: "VIP" };

        card.innerHTML = `
            <div class="client-card-header">
                <div class="client-avatar-row">
                    <div class="client-letter-avatar">${firstLetter}</div>
                    <div class="client-name-phone">
                        <h3>${c.name}</h3>
                        <p>${c.phone}</p>
                    </div>
                </div>
                <span class="client-type-badge ${c.type}">${clientTypeNames[c.type]}</span>
            </div>
            
            <div class="client-card-body">
                <div class="client-policy-item">
                    <span class="client-policy-label">유지 상품:</span>
                    <span class="client-policy-value">${c.policy}</span>
                </div>
                ${c.notes ? `<p class="client-notes-preview">${c.notes}</p>` : ""}
            </div>

            <div class="client-card-footer">
                <button class="btn-client-action btn-add-client-event" data-id="${c.id}" data-name="${c.name}">
                    <i data-lucide="plus"></i>
                    <span>일정 등록</span>
                </button>
                <button class="btn-delete-client" data-id="${c.id}">
                    <i data-lucide="trash-2"></i>
                </button>
            </div>
        `;

        card.querySelector(".btn-delete-client").addEventListener("click", (evt) => {
            evt.stopPropagation();
            if (confirm(`${c.name} 고객을 삭제하시겠습니까? 등록된 일정도 함께 점검해주세요.`)) {
                clients = clients.filter(cl => cl.id !== c.id);
                saveToLocalStorage();
                renderClients();
                updateDashboard();
            }
        });

        card.querySelector(".btn-add-client-event").addEventListener("click", () => {
            const eventModal = document.getElementById("event-modal");
            eventModal.classList.add("active");
            populateClientSelects();
            const select = document.getElementById("event-client-select");
            if (select) select.value = c.id;
        });

        container.appendChild(card);
    });

    lucide.createIcons();
}

// 도너츠 메뉴 토글 기능
document.addEventListener('DOMContentLoaded', () => {
    const donutMenuBtn = document.getElementById('donutMenuBtn');
    const donutNavMenu = document.querySelector('.donut-menu-container .nav-menu');

    if (donutMenuBtn && donutNavMenu) {
        // 버튼 클릭 시 메뉴 보여주기/숨기기 토글
        donutMenuBtn.addEventListener('click', (e) => {
            e.stopPropagation(); // 부모 윈도우 클릭 이벤트 전파 방지
            donutNavMenu.classList.toggle('show');
        });

        // 메뉴 바깥 화면을 클릭하면 메뉴가 자동으로 닫히도록 설정
        document.addEventListener('click', (e) => {
            if (!donutNavMenu.contains(e.target) && e.target !== donutMenuBtn) {
                donutNavMenu.classList.remove('show');
            }
        });
    }
});